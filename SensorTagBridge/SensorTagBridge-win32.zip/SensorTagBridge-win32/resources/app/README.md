# SensorTagBridge
an electron app to forward sensor tags value over OSC
